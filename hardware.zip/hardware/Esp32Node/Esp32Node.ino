#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>

// ======== WIFI CREDENTIALS ========
const char* ssid = "STARK NETWORKS";
const char* password = "Vinod630211";

// ======== SERVER =========
WebServer server(80);

// ======== MOTOR PINS (L298N) ========
#define IN1 26
#define IN2 27
#define IN3 14
#define IN4 12

// ======== SERVO =========
Servo myServo;
#define SERVO_PIN 13

// ======== MOTOR FUNCTIONS =========
void stopMotors() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
  server.send(200, "text/plain", "STOP");
}

void forward() {
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
  server.send(200, "text/plain", "FORWARD");
}

void backward() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
  server.send(200, "text/plain", "BACKWARD");
}

void left() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
  digitalWrite(IN3, HIGH);
  digitalWrite(IN4, LOW);
  server.send(200, "text/plain", "LEFT");
}

void right() {
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
  server.send(200, "text/plain", "RIGHT");
}

// ======== SETUP =========
void setup() {
  Serial.begin(115200);

  // Motor pins
  pinMode(IN1, OUTPUT);
  pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT);
  pinMode(IN4, OUTPUT);

  stopMotors();

  // Servo
  myServo.attach(SERVO_PIN);
  myServo.write(90);

  // WiFi connect
  WiFi.mode(WIFI_STA);
  WiFi.begin(ssid, password);

  Serial.print("Connecting to WiFi");

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  Serial.println("\nConnected!");
  Serial.print("IP Address: ");
  Serial.println(WiFi.localIP());

  // ======== ROUTES =========

  // ROOT ROUTE (IMPORTANT)
  server.on("/", []() {
    server.send(200, "text/plain", "ESP32 Robot Server Working");
  });

  server.on("/forward", forward);
  server.on("/backward", backward);
  server.on("/left", left);
  server.on("/right", right);
  server.on("/stop", stopMotors);

  server.on("/servo", []() {
    if (server.hasArg("angle")) {
      int angle = server.arg("angle").toInt();
      angle = constrain(angle, 0, 180);
      myServo.write(angle);
      server.send(200, "text/plain", "Servo moved to " + String(angle));
    } else {
      server.send(400, "text/plain", "Missing angle parameter");
    }
  });

  server.begin();
  Serial.println("HTTP Server Started");
}

// ======== LOOP =========
void loop() {
  server.handleClient();
}
