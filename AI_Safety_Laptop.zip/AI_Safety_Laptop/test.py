from twilio.rest import Client

# 🔐 Replace with your real credentials
account_sid = "ACd1c19f4240646c1cc744269eceb80ba2"
auth_token = "8a3f009bb151c93c7ea9d01605aaf045"

# Your Twilio number (from dashboard)
twilio_number = "+14176602520"

# Parent number (must include country code)
to_number = "+916302112377"

try:
    client = Client(account_sid, auth_token)

    message = client.messages.create(
        body="✅ Twilio Test Successful! Your Child Safety System SMS is working.",
        from_=twilio_number,
        to=to_number
    )

    print("✅ SMS Sent Successfully!")
    print("Message SID:", message.sid)

except Exception as e:
    print("❌ Error Sending SMS:")
    print(e)
