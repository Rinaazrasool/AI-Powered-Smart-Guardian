from flask import Flask, render_template, Response, jsonify
import cv2
import time
from ultralytics import YOLO
import pywhatkit as kit
import datetime

app = Flask(__name__)

# -----------------------------
# CONFIGURATION
# -----------------------------

VIDEO_SOURCE = 0  # 0 = Laptop Webcam
model = YOLO("yolov8n.pt")

ALERT_COOLDOWN = 20  # seconds

# 🔴 PUT PARENT NUMBER WITH COUNTRY CODE
PARENT_WHATSAPP = "+916302112377"

# -----------------------------
# GLOBAL VARIABLES
# -----------------------------

current_status = {
    "risk_level": 0,
    "status": "Safe",
    "timestamp": time.time()
}

camera = cv2.VideoCapture(VIDEO_SOURCE)

last_alert_time = 0
previous_child_center_y = None

# -----------------------------
# ALERT FUNCTION
# -----------------------------

def send_alert(message):
    global last_alert_time

    if time.time() - last_alert_time < ALERT_COOLDOWN:
        return

    last_alert_time = time.time()

    print("🚨 ALERT:", message)

    try:
        kit.sendwhatmsg_instantly(
            PARENT_WHATSAPP,
            message,
            wait_time=20,
            tab_close=True,
            close_time=5
        )

        print("✅ WhatsApp Message Sent Instantly")

    except Exception as e:
        print("WhatsApp Error:", e)

# -----------------------------
# VIDEO PROCESSING
# -----------------------------

def generate_frames():
    global current_status, previous_child_center_y

    while True:
        success, frame = camera.read()
        if not success:
            break

        results = model(frame, verbose=False)
        result = results[0]

        child_box = None

        for box in result.boxes:
            class_id = int(box.cls[0])
            class_name = result.names[class_id]
            confidence = float(box.conf[0])

            if confidence < 0.5:
                continue

            coords = [int(c) for c in box.xyxy[0]]
            (x1, y1, x2, y2) = coords

            if class_name == 'person':
                child_box = coords
                cv2.rectangle(frame, (x1, y1), (x2, y2), (255, 0, 0), 2)

        risk_level = 10
        status_text = "Safe"
        fall_detected = False

        if child_box:
            x1, y1, x2, y2 = child_box
            width = x2 - x1
            height = y2 - y1
            center_y = (y1 + y2) // 2

            # Horizontal body condition
            if width > height * 1.2:
                fall_detected = True

            # Sudden downward movement
            if previous_child_center_y is not None:
                if center_y - previous_child_center_y > 40:
                    fall_detected = True

            previous_child_center_y = center_y

        if fall_detected:
            status_text = "🚨 CRITICAL: CHILD FALL DETECTED!"
            risk_level = 100
            send_alert(status_text)

        current_status = {
            "risk_level": risk_level,
            "status": status_text,
            "timestamp": time.time()
        }

        color = (0, 0, 255) if risk_level > 50 else (0, 255, 0)

        cv2.putText(frame, status_text, (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 1, color, 2)

        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

# -----------------------------
# ROUTES
# -----------------------------

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(),
                    mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/get_status')
def get_status():
    return jsonify(current_status)

# -----------------------------
# RUN SERVER
# -----------------------------

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=False)