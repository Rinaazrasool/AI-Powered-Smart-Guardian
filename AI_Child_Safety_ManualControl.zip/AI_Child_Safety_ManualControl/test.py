from twilio.rest import Client

# 🔐 Replace with your real credentials
account_sid = "AC7d84cf836c42b3266ea5e067833396f3"
auth_token = "ca994a26185b1503351e654b27154baa"

# Your Twilio number (from dashboard)
twilio_number = "+19787978120"

# Parent number (must include country code)
to_number = "+916302112377"

try:
    client = Client(account_sid, auth_token)

    message = client.messages.create(
        body="✅ Twilio Test Successful! Your Child Safety System SMS is working.",
        from_=twilio_number,
        to=to_number
    )

    print("✅ SMS Sent Successfully!")
    print("Message SID:", message.sid)

except Exception as e:
    print("❌ Error Sending SMS:")
    print(e)
